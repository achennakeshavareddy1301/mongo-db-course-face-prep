import React from 'react'

export default function About() {
  return (
    <div className='container-fluid p-5'>
        <h1>Inventory Management System - MERN CRUD App</h1>
        <p>...</p>
    </div>
  )
}
