import React from 'react'

export default function Home() {
  return (
    <div className='container-fluid p-5'>
        <h2>Go to Products Section.</h2>
    </div>
  )
}
